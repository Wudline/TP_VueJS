<template>
  <p>Recherche</p>
</template>

<script>
export default {
  name: 'Recherche',
  data () {
    return {}
  }
}
</script>
