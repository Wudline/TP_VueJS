
<template>
  <div>
    <p>Config</p>
    <Recherche />
    <Stat />

    <select>
        <option v-for="data in filteredItems" :key="data.id">{{ data[0] }}</option>
    </select>
    <p>{{ filteredItems }}</p>
  </div>
</template>

<script>
import Recherche from '@/components/Recherche'
import Stat from '@/components/Stat'

import { sortTable } from '@/assets/data.min.js'

export default {
  name: 'Config',
  components: {
    Recherche,
    Stat
  },
  data () {
    return {}
  },
  computed: {
    filteredItems () {
      sortTable.filter( (value, index, self) => 
      {
        return self.indexOf(value) === index;
      } );
    }
  }
}
</script>
